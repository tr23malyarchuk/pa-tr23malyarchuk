#ifndef ARCTANGENT_H
#define ARCTANGENT_H

class Arctangent // holding a class with a public function FuncA
{
    public:
        double FuncA(double x, int n);
};

#endif
